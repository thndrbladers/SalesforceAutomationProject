To regenerate deps.js:
$./go calcdeps

To run the tests locally, start the webserver:
$./go debug-server

You can access it in your browser at http://localhost:2310/javascript.
