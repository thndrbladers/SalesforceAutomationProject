// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package org.openqa.selenium.htmlunit;

import static com.gargoylesoftware.htmlunit.BrowserVersion.FIREFOX;
import static com.gargoylesoftware.htmlunit.BrowserVersion.FIREFOX_ESR;
import static com.gargoylesoftware.htmlunit.BrowserVersion.INTERNET_EXPLORER;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.openqa.selenium.htmlunit.HtmlUnitDriver.BROWSER_LANGUAGE_CAPABILITY;
import static org.openqa.selenium.htmlunit.HtmlUnitDriver.JAVASCRIPT_ENABLED;

import org.junit.Test;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.testing.drivers.BrowserToCapabilities;
import org.openqa.selenium.testing.drivers.BrowserType;

import com.gargoylesoftware.htmlunit.BrowserVersion;

/**
 * Test the determineBrowserVersion method.
 */
public class HtmlUnitCapabilitiesTest {

  @Test
  public void configurationViaDirectCapabilities() {
    DesiredCapabilities ieCapabilities = BrowserToCapabilities.of(BrowserType.IE);

    try {
        BrowserVersionDeterminer.determine(ieCapabilities);
        fail("IllegalArgumentException expected");
    }
    catch (IllegalArgumentException e) {
        assertEquals("When building an HtmlUntDriver, the capability browser name "
                        + "must be set to 'htmlunit' but was 'internet explorer'.", e.getMessage());
    }
  }

  @Test
  public void configurationOfFirefoxDefaultViaRemote() {
    DesiredCapabilities firefoxCapabilities = BrowserToCapabilities.of(BrowserType.HTML_UNIT, "firefox");
    assertEquals(FIREFOX, BrowserVersionDeterminer.determine(firefoxCapabilities));
  }

  @Test
  public void configurationOfFirefox78ViaRemote() {
    DesiredCapabilities firefoxCapabilities = BrowserToCapabilities.of(BrowserType.HTML_UNIT, "firefox-78");
    assertEquals(FIREFOX_ESR, BrowserVersionDeterminer.determine(firefoxCapabilities));
  }

  @Test
  public void configurationOfFirefox91ViaRemote() {
    DesiredCapabilities firefoxCapabilities = BrowserToCapabilities.of(BrowserType.HTML_UNIT, "firefox-91");
    assertEquals(FIREFOX_ESR, BrowserVersionDeterminer.determine(firefoxCapabilities));
  }

  @Test
  public void configurationOfFirefoxEsrViaRemote() {
    DesiredCapabilities firefoxCapabilities = BrowserToCapabilities.of(BrowserType.HTML_UNIT, "firefox-esr");
    assertEquals(FIREFOX_ESR, BrowserVersionDeterminer.determine(firefoxCapabilities));
  }

  @Test
  public void configurationOfIEViaRemote() {
    DesiredCapabilities ieCapabilities = BrowserToCapabilities.of(BrowserType.HTML_UNIT, "internet explorer");
    assertEquals(INTERNET_EXPLORER, BrowserVersionDeterminer.determine(ieCapabilities));
  }

  @Test
  public void tetsDefautlBrowserVersion() {
    DesiredCapabilities capabilities = BrowserToCapabilities.of(BrowserType.HTML_UNIT);

    assertEquals(BrowserVersion.getDefault(), BrowserVersionDeterminer.determine(capabilities));
  }

  @Test
  public void htmlUnitReportsCapabilities() {
    HtmlUnitDriver driver = new HtmlUnitDriver(true);
    Capabilities jsEnabled = driver.getCapabilities();
    driver.quit();

    driver = new HtmlUnitDriver(false);
    Capabilities jsDisabled = driver.getCapabilities();
    assertTrue(jsEnabled.is(JAVASCRIPT_ENABLED));
    assertFalse(jsDisabled.is(JAVASCRIPT_ENABLED));
  }

  @Test
  public void configurationOfBrowserLanguage() {
    String browserLanguage = "es-ES";

    DesiredCapabilities capabilities = BrowserToCapabilities.of(BrowserType.HTML_UNIT);
    capabilities.setCapability(BROWSER_LANGUAGE_CAPABILITY, browserLanguage);

    assertEquals(browserLanguage, BrowserVersionDeterminer.determine(capabilities).getBrowserLanguage());
  }

}
